
import os
import cv2
import numpy as np

INPUT_DIR = "recorded_data"
OUTPUT_IMG_DIR = "dataset/images"
OUTPUT_MASK_DIR = "dataset/masks"

os.makedirs(OUTPUT_IMG_DIR, exist_ok=True)
os.makedirs(OUTPUT_MASK_DIR, exist_ok=True)

for file in os.listdir(INPUT_DIR):
    if not file.endswith(".jpg"):
        continue

    img_path = os.path.join(INPUT_DIR, file)
    image = cv2.imread(img_path)

    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    lower_white = np.array([0, 0, 180])
    upper_white = np.array([180, 50, 255])
    white_mask = cv2.inRange(hsv, lower_white, upper_white)

    lower_black = np.array([0, 0, 0])
    upper_black = np.array([180, 255, 50])
    black_mask = cv2.inRange(hsv, lower_black, upper_black)

    mask = cv2.bitwise_or(white_mask, black_mask)

    kernel = np.ones((5,5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

    cv2.imwrite(os.path.join(OUTPUT_IMG_DIR, file), image)
    cv2.imwrite(os.path.join(OUTPUT_MASK_DIR, file), mask)

print("Automatic mask generation complete.")
