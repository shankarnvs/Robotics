
import tensorflow as tf
from tensorflow.keras import layers, models
import os
import cv2
import numpy as np

IMG_SIZE = (256, 512)
IMG_DIR = "dataset/images"
MASK_DIR = "dataset/masks"

def load_data():
    images = []
    masks = []
    for file in os.listdir(IMG_DIR):
        img = cv2.imread(os.path.join(IMG_DIR, file))
        mask = cv2.imread(os.path.join(MASK_DIR, file), 0)

        img = cv2.resize(img, IMG_SIZE[::-1])
        mask = cv2.resize(mask, IMG_SIZE[::-1])

        img = img / 255.0
        mask = np.expand_dims(mask / 255.0, axis=-1)

        images.append(img)
        masks.append(mask)

    return np.array(images), np.array(masks)

def build_unet():
    inputs = layers.Input((*IMG_SIZE, 3))

    c1 = layers.Conv2D(32, 3, activation='relu', padding='same')(inputs)
    c1 = layers.Conv2D(32, 3, activation='relu', padding='same')(c1)
    p1 = layers.MaxPooling2D()(c1)

    c2 = layers.Conv2D(64, 3, activation='relu', padding='same')(p1)
    c2 = layers.Conv2D(64, 3, activation='relu', padding='same')(c2)

    u1 = layers.UpSampling2D()(c2)
    concat = layers.Concatenate()([u1, c1])

    outputs = layers.Conv2D(1, 1, activation='sigmoid')(concat)

    return models.Model(inputs, outputs)

X, y = load_data()

model = build_unet()
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

model.fit(X, y, epochs=10, batch_size=4)

model.save("lane_model.h5")
print("Training complete. Model saved as lane_model.h5")
