
import cv2
import numpy as np
from picamera2 import Picamera2
import time
import os

class PerceptionRecorder:
    def __init__(self):
        self.picam2 = Picamera2()

        config = self.picam2.create_preview_configuration(
            main={"size": (2592, 1944), "format": "RGB888"},
            controls={"FrameRate": 15}
        )

        self.picam2.configure(config)
        self.picam2.start()
        time.sleep(1)

        self.dataset_dir = "recorded_data"
        os.makedirs(self.dataset_dir, exist_ok=True)

        print("Full Resolution Corrected Recording Mode Initialized")

    def glare_correction(self, frame):
        hsv = cv2.cvtColor(frame, cv2.COLOR_RGB2HSV)
        h, s, v = cv2.split(hsv)

        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        v = clahe.apply(v)

        mask = cv2.inRange(v, 240, 255)
        v[mask > 0] = 200

        hsv = cv2.merge((h, s, v))
        corrected = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
        return corrected

    def capture_and_save(self):
        frame = self.picam2.capture_array()
        corrected = self.glare_correction(frame)

        timestamp = int(time.time() * 1000)
        path = os.path.join(self.dataset_dir, f"{timestamp}.jpg")

        cv2.imwrite(path, cv2.cvtColor(corrected, cv2.COLOR_RGB2BGR))
        return corrected

    def cleanup(self):
        self.picam2.stop()
