
import tensorflow as tf
import tf2onnx
import onnx

model = tf.keras.models.load_model("lane_model.h5")

spec = (tf.TensorSpec((1, 256, 512, 3), tf.float32, name="input"),)
model_proto, _ = tf2onnx.convert.from_keras(model, input_signature=spec)
onnx.save(model_proto, "lane_model.onnx")

converter = tf.lite.TFLiteConverter.from_keras_model(model)
tflite_model = converter.convert()

with open("lane_model.tflite", "wb") as f:
    f.write(tflite_model)

print("Exported: H5, ONNX, TFLite")
