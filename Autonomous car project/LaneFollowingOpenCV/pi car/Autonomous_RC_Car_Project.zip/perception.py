import cv2
import numpy as np

class Perception:
    def __init__(self, road_color="BLACK", border_color="WHITE"):
        self.road_color = road_color
        self.border_color = border_color

        self.cap = cv2.VideoCapture(0)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)
        self.cap.set(cv2.CAP_PROP_FPS, 30)

    def _threshold_type(self):
        return cv2.THRESH_BINARY_INV if self.road_color == "BLACK" else cv2.THRESH_BINARY

    def process_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            return None, None, None

        raw = frame.copy()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        h, w = gray.shape
        roi = gray[int(h * 0.6):h, :]

        _, binary = cv2.threshold(roi, 120, 255, self._threshold_type())
        binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))

        slice_centers = []
        slice_h = binary.shape[0] // 5

        for i in range(5):
            slice_img = binary[i * slice_h:(i + 1) * slice_h, :]
            contours, _ = cv2.findContours(slice_img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            if contours:
                largest = max(contours, key=cv2.contourArea)
                M = cv2.moments(largest)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    slice_centers.append(cx)

        steer = "no steer"
        if len(slice_centers) >= 3:
            slope = slice_centers[-1] - slice_centers[0]
            if slope > 20:
                steer = "right"
            elif slope < -20:
                steer = "left"

        processed = cv2.cvtColor(binary, cv2.COLOR_GRAY2BGR)
        return steer, raw, processed

    def cleanup(self):
        self.cap.release()