import threading
import queue
import time

from perception import Perception
from actuation import Actuation

command_queue = queue.Queue()
shutdown_event = threading.Event()

def perception_thread(per):
    while not shutdown_event.is_set():
        steer, _, _ = per.process_frame()
        if steer:
            command_queue.put(steer)

def control_thread(act):
    while not shutdown_event.is_set():
        try:
            steer = command_queue.get(timeout=0.1)
            act.navigate(steer, "fwd")
        except queue.Empty:
            pass

def main():
    per = Perception("BLACK", "WHITE")
    act = Actuation()

    threading.Thread(target=perception_thread, args=(per,), daemon=True).start()
    threading.Thread(target=control_thread, args=(act,), daemon=True).start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        shutdown_event.set()
        per.cleanup()
        act.cleanup()

if __name__ == "__main__":
    main()