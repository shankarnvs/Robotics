import RPi.GPIO as GPIO
import time
import threading

class Actuation:
    def __init__(self):
        self.lock = threading.Lock()

        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)

        # Steering motor (M1)
        self.ENA = 17
        self.IN1 = 27
        self.IN2 = 22

        # Drive motor (M2)
        self.IN3 = 23
        self.IN4 = 24
        self.ENB = 25

        for pin in [self.ENA, self.IN1, self.IN2, self.IN3, self.IN4, self.ENB]:
            GPIO.setup(pin, GPIO.OUT)
            GPIO.output(pin, GPIO.LOW)

        GPIO.output(self.ENA, GPIO.HIGH)

        self.drive_pwm = GPIO.PWM(self.ENB, 1000)
        self.drive_pwm.start(0)

    def steer(self, direction):
        with self.lock:
            if direction == "left":
                GPIO.output(self.IN1, GPIO.HIGH)
                GPIO.output(self.IN2, GPIO.LOW)
            elif direction == "right":
                GPIO.output(self.IN1, GPIO.LOW)
                GPIO.output(self.IN2, GPIO.HIGH)
            else:
                GPIO.output(self.IN1, GPIO.LOW)
                GPIO.output(self.IN2, GPIO.LOW)

    def drive(self, direction):
        with self.lock:
            if direction == "fwd":
                GPIO.output(self.IN3, GPIO.HIGH)
                GPIO.output(self.IN4, GPIO.LOW)
            elif direction == "bck":
                GPIO.output(self.IN3, GPIO.LOW)
                GPIO.output(self.IN4, GPIO.HIGH)

            self.drive_pwm.ChangeDutyCycle(25)

        time.sleep(1)

        with self.lock:
            self.drive_pwm.ChangeDutyCycle(0)
            GPIO.output(self.IN3, GPIO.LOW)
            GPIO.output(self.IN4, GPIO.LOW)

    def navigate(self, steer_dir, drive_dir):
        self.steer(steer_dir)
        self.drive(drive_dir)

    def cleanup(self):
        self.drive_pwm.stop()
        GPIO.cleanup()