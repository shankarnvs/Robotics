import RPi.GPIO as GPIO
import time
import threading
class Actuation:
    def __init__(self):
        self.lock = threading.Lock()
        GPIO.setmode(GPIO.BCM); GPIO.setwarnings(False)
        self.ENA, self.IN1, self.IN2 = 17,27,22
        self.IN3, self.IN4, self.ENB = 23,24,25
        for p in [self.ENA,self.IN1,self.IN2,self.IN3,self.IN4,self.ENB]:
            GPIO.setup(p, GPIO.OUT); GPIO.output(p, GPIO.LOW)
        GPIO.output(self.ENA, GPIO.HIGH)
        self.drive_pwm = GPIO.PWM(self.ENB,1000); self.drive_pwm.start(0)
    def steer(self, d):
        with self.lock:
            if d=="left": GPIO.output(self.IN1,1); GPIO.output(self.IN2,0)
            elif d=="right": GPIO.output(self.IN1,0); GPIO.output(self.IN2,1)
            else: GPIO.output(self.IN1,0); GPIO.output(self.IN2,0)
    def drive(self, d):
        with self.lock:
            if d=="fwd": GPIO.output(self.IN3,1); GPIO.output(self.IN4,0)
            elif d=="bck": GPIO.output(self.IN3,0); GPIO.output(self.IN4,1)
            self.drive_pwm.ChangeDutyCycle(25)
        time.sleep(1)
        with self.lock:
            self.drive_pwm.ChangeDutyCycle(0)
            GPIO.output(self.IN3,0); GPIO.output(self.IN4,0)
    def navigate(self,s,d): self.steer(s); self.drive(d)
    def cleanup(self): self.drive_pwm.stop(); GPIO.cleanup()
