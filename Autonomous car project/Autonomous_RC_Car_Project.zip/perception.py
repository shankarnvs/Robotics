import cv2, numpy as np
class Perception:
    def __init__(self, road_color="BLACK", border_color="WHITE"):
        self.road_color=road_color
        self.cap=cv2.VideoCapture(0)
        self.cap.set(3,320); self.cap.set(4,240)
    def _t(self): return cv2.THRESH_BINARY_INV if self.road_color=="BLACK" else cv2.THRESH_BINARY
    def process_frame(self):
        r,f=self.cap.read()
        if not r: return None,None,None
        raw=f.copy()
        g=cv2.cvtColor(f,cv2.COLOR_BGR2GRAY)
        h,w=g.shape; roi=g[int(h*0.6):h,:]
        _,b=cv2.threshold(roi,120,255,self._t())
        cs,_=cv2.findContours(b,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        steer="no steer"
        if cs:
            c=max(cs,key=cv2.contourArea)
            M=cv2.moments(c)
            if M["m00"]!=0:
                cx=int(M["m10"]/M["m00"])
                if cx-w//2>30: steer="right"
                elif cx-w//2<-30: steer="left"
        return steer, raw, cv2.cvtColor(b,cv2.COLOR_GRAY2BGR)
    def cleanup(self): self.cap.release()
