from perception import Perception
from actuation import Actuation
import threading,queue,time
q=queue.Queue()
stop=threading.Event()
def p(per):
    while not stop.is_set():
        s,_,_=per.process_frame()
        if s: q.put(s)
def c(act):
    while not stop.is_set():
        try: act.navigate(q.get(0.1),"fwd")
        except: pass
def main():
    per=Perception(); act=Actuation()
    threading.Thread(target=p,args=(per,),daemon=True).start()
    threading.Thread(target=c,args=(act,),daemon=True).start()
    try:
        while True: time.sleep(1)
    except KeyboardInterrupt:
        stop.set(); per.cleanup(); act.cleanup()
if __name__=="__main__": main()
